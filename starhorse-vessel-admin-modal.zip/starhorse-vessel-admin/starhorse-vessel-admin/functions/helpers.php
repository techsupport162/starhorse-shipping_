<?php
/**
 * functions/helpers.php
 * -----------------------------------------------------------------------
 * Small, dependency-free utility functions shared across the admin CMS:
 * CSRF tokens, flash messages, input sanitization, and image upload
 * validation. Keeping these in one place avoids duplicated code across
 * modules.
 * -----------------------------------------------------------------------
 */

/** Generate (or reuse) the CSRF token for the current session. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Echo a hidden CSRF input field for use inside admin forms/modals. */
function csrf_field(): void
{
    echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

/**
 * Validate a submitted CSRF token. On AJAX endpoints, call this first and
 * bail out with a 403 JSON response if it fails.
 */
function csrf_verify(?string $submittedToken): bool
{
    return !empty($submittedToken)
        && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $submittedToken);
}

/** Send a standard JSON response and stop execution. */
function json_response(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit;
}

/** Shortcut for a failed JSON response with a message. */
function json_error(string $message, int $statusCode = 400, array $extra = []): void
{
    json_response(array_merge(['success' => false, 'message' => $message], $extra), $statusCode);
}

/**
 * Send field-level validation errors, e.g.
 *   json_field_errors(['email' => 'That email is already in use.', 'username' => 'Too short.']);
 * The frontend's ShValidator.mapBackendErrors() reads the `errors` object
 * and shows each message directly under its matching form field (by
 * `name`), instead of one generic alert. Any key that doesn't match a
 * field on the form falls back to the modal's top alert box, so
 * business-rule errors that aren't about one specific field (e.g. "at
 * least one administrator must remain") still surface clearly.
 *
 * This is additive — json_error()/json_response() are unchanged and still
 * used as before for non-field errors (CSRF, not-found, server errors).
 *
 * @param array  $fields  ['fieldName' => 'Error message', ...] — at least one entry
 * @param string $message top-level fallback summary shown if nothing maps
 */
function json_field_errors(array $fields, int $statusCode = 422, string $message = 'Please correct the highlighted fields.'): void
{
    json_response([
        'success' => false,
        'message' => $message,
        'errors'  => $fields,
    ], $statusCode);
}

/** Store a one-time flash message shown after a redirect (e.g. after login). */
function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/** Retrieve and clear the flash message, if any. */
function get_flash(): ?array
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

/** Basic RFC-compliant email format check (uniqueness is checked separately at the DB layer). */
function is_valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/** Minimum password policy: at least 8 characters. Kept intentionally simple and documented. */
function is_valid_password(string $password): bool
{
    return mb_strlen($password) >= 8;
}

/** Trim a plain text field submitted from a form. */
function clean_str(?string $value): string
{
    return trim($value ?? '');
}

/**
 * Parse a numeric spec field (length, breadth, depth, gross tonnage).
 * Returns null for blank input so optional fields stay NULL in the DB,
 * or a float rounded to 2 decimals.
 */
function clean_decimal(?string $value): ?float
{
    $value = trim($value ?? '');
    if ($value === '') {
        return null;
    }
    if (!is_numeric($value) || (float) $value < 0) {
        return null;
    }
    return round((float) $value, 2);
}

/**
 * Companion to clean_decimal() for CRUD endpoints that want a field-level
 * error message (via json_field_errors()) instead of silently coercing an
 * invalid value to null. A blank value is valid — these spec fields are
 * optional — only a non-numeric or negative value is flagged.
 */
function validate_decimal_field(?string $value, string $label): ?string
{
    $value = trim($value ?? '');
    if ($value === '') {
        return null;
    }
    if (!is_numeric($value)) {
        return $label . ' must be a valid number.';
    }
    if ((float) $value < 0) {
        return $label . ' cannot be negative.';
    }
    return null;
}

/**
 * Validate a single uploaded image ($_FILES entry). Checks the upload
 * error code, real MIME type (via finfo, not the client-supplied one),
 * extension, and file size.
 *
 * @return array{ok: bool, error?: string, ext?: string}
 */
function validate_image_upload(array $file, int $maxBytes = 5 * 1024 * 1024, ?array $allowedMimes = null): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'error' => 'No file was uploaded.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Upload failed (error code ' . $file['error'] . ').'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'error' => 'Invalid upload.'];
    }
    if ($file['size'] > $maxBytes) {
        return ['ok' => false, 'error' => 'Image exceeds the 5MB limit.'];
    }

    $allowed = $allowedMimes ?? [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    $finfo    = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($allowed[$mimeType])) {
        return ['ok' => false, 'error' => 'Only JPG, PNG, WEBP, or GIF images are allowed.'];
    }

    // getimagesize() also confirms the file is genuinely a valid image,
    // guarding against disguised/renamed non-image files.
    if (@getimagesize($file['tmp_name']) === false) {
        return ['ok' => false, 'error' => 'File is not a valid image.'];
    }

    return ['ok' => true, 'ext' => $allowed[$mimeType]];
}

/**
 * Move a validated upload into uploads/<subdir>/ with a random,
 * collision-safe filename, and return the stored filename (not the full
 * path). Shared by the Vessel and User (profile image) modules.
 */
function store_uploaded_image(array $file, string $ext, string $subdir): string
{
    $filename    = $subdir . '_' . bin2hex(random_bytes(8)) . '_' . time() . '.' . $ext;
    $uploadDir   = __DIR__ . '/../uploads/' . $subdir . '/';
    $destination = $uploadDir . $filename;

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Could not save uploaded image.');
    }

    return $filename;
}

/** Remove an uploaded image file from uploads/<subdir>/ if it exists. */
function delete_uploaded_image_file(string $filename, string $subdir): void
{
    if ($filename === '') {
        return;
    }
    $path = __DIR__ . '/../uploads/' . $subdir . '/' . basename($filename);
    if (is_file($path)) {
        @unlink($path);
    }
}

/**
 * Move a validated upload into uploads/vessels/ (kept for backward
 * compatibility with the existing Vessel module — internally delegates
 * to the generic store_uploaded_image()).
 */
function store_vessel_image(array $file, string $ext): string
{
    return store_uploaded_image($file, $ext, 'vessels');
}

/**
 * Process a validated profile-photo upload into a square "2x2" ID-photo
 * style thumbnail: center-crops to a square (using the shorter side),
 * resizes down to $size x $size, flattens any transparency onto white,
 * and always saves as a JPG for a small, consistent file size. Used by
 * the User Management module so every stored profile image is uniform
 * regardless of what aspect ratio or resolution was uploaded.
 *
 * @param array  $file validated $_FILES entry
 * @param string $ext  'jpg' | 'jpeg' | 'png' | 'webp' (from validate_image_upload())
 * @param int    $size output width/height in pixels (400 = a crisp square thumbnail)
 * @return string stored filename (always .jpg)
 */
function process_and_store_profile_image(array $file, string $ext, int $size = 400): string
{
    if (!function_exists('imagecreatetruecolor')) {
        throw new RuntimeException('The PHP GD extension is required to process images but is not enabled.');
    }

    $tmpPath = $file['tmp_name'];
    $ext = strtolower($ext) === 'jpeg' ? 'jpg' : strtolower($ext);

    switch ($ext) {
        case 'jpg':
            $source = @imagecreatefromjpeg($tmpPath);
            $source = $source ? fix_jpeg_orientation($source, $tmpPath) : $source;
            break;
        case 'png':
            $source = @imagecreatefrompng($tmpPath);
            break;
        case 'webp':
            if (!function_exists('imagecreatefromwebp')) {
                throw new RuntimeException('WEBP images are not supported by this server. Please upload a JPG or PNG instead.');
            }
            $source = @imagecreatefromwebp($tmpPath);
            break;
        default:
            throw new RuntimeException('Unsupported image type.');
    }

    if (!$source) {
        throw new RuntimeException('Could not read the uploaded image.');
    }

    $srcWidth  = imagesx($source);
    $srcHeight = imagesy($source);
    $cropSize  = min($srcWidth, $srcHeight);
    $cropX     = intdiv($srcWidth - $cropSize, 2);
    $cropY     = intdiv($srcHeight - $cropSize, 2);

    // Flatten onto a white canvas first (handles PNG/WEBP transparency
    // consistently instead of leaving black or undefined backgrounds).
    $square = imagecreatetruecolor($size, $size);
    $white  = imagecolorallocate($square, 255, 255, 255);
    imagefill($square, 0, 0, $white);
    imagecopyresampled($square, $source, 0, 0, $cropX, $cropY, $size, $size, $cropSize, $cropSize);
    imagedestroy($source);

    $filename    = 'users_' . bin2hex(random_bytes(8)) . '_' . time() . '.jpg';
    $uploadDir   = __DIR__ . '/../uploads/users/';
    $destination = $uploadDir . $filename;

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $saved = imagejpeg($square, $destination, 88);
    imagedestroy($square);

    if (!$saved) {
        throw new RuntimeException('Could not save the processed profile photo.');
    }

    return $filename;
}

/**
 * Reads EXIF orientation from a JPEG and rotates the in-memory image
 * upright before cropping — without this, portrait phone-camera photos
 * often get saved sideways because JPEG stores rotation as metadata
 * rather than actually rotating the pixel data.
 *
 * @param \GdImage|resource $image
 * @param string $path original file path (to re-read EXIF data from)
 * @return \GdImage|resource
 */
function fix_jpeg_orientation($image, string $path)
{
    if (!function_exists('exif_read_data')) {
        return $image; // exif extension not enabled — skip silently, non-critical
    }

    $exif = @exif_read_data($path);
    if (empty($exif['Orientation'])) {
        return $image;
    }

    switch ($exif['Orientation']) {
        case 3:
            return imagerotate($image, 180, 0);
        case 6:
            return imagerotate($image, -90, 0);
        case 8:
            return imagerotate($image, 90, 0);
        default:
            return $image;
    }
}
