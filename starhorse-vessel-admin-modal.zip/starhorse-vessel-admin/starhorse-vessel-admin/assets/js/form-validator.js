/**
 * assets/js/form-validator.js
 * ---------------------------------------------------------------------
 * ShValidator — the CMS's single reusable field-level validation engine.
 * Used by every CRUD form (Vessels, Users, and future modules) so
 * validation behaves identically everywhere: errors render directly
 * under their field, never as a single top-of-form alert.
 *
 * Deliberately built on Bootstrap's OWN validation styling
 * (`.is-invalid` + `.invalid-feedback`) rather than inventing a new
 * visual language — that's already in the CSS you're loading, keeps
 * every form consistent with the existing design system for free, and
 * needs zero new theme CSS.
 *
 * ------------------------------------------------------------------
 * USAGE (a module's own JS file does this — see Phase 3 for the
 * Vessel module wiring):
 *
 *   const schema = {
 *     name:  { required: true, label: 'Vessel Name', maxLength: 150 },
 *     email: { required: true, type: 'email' },
 *     length_m: { type: 'number', min: 0 },
 *     confirm_password: { required: true, match: 'password' },
 *   };
 *
 *   ShValidator.attachLiveValidation(formEl, schema);   // once, on init
 *
 *   // on submit:
 *   const result = ShValidator.validateForm(formEl, schema);
 *   if (!result.valid) { ShValidator.focusFirstInvalid(formEl); return; }
 *
 *   // after a failed AJAX call that returned { errors: {...} }:
 *   const unmapped = ShValidator.mapBackendErrors(formEl, response.errors);
 *   // `unmapped` = messages whose key didn't match any field name —
 *   // show those in the form's existing top alert box as a fallback.
 * ------------------------------------------------------------------
 */
(function () {
  'use strict';

  var DEFAULT_MESSAGES = {
    required: function (label) { return label + ' is required.'; },
    email: function () { return 'Please enter a valid email address.'; },
    number: function () { return 'Please enter a valid number.'; },
    minLength: function (label, n) { return label + ' must be at least ' + n + ' characters.'; },
    maxLength: function (label, n) { return label + ' must be ' + n + ' characters or fewer.'; },
    min: function (label, n) { return label + ' must be at least ' + n + '.'; },
    max: function (label, n) { return label + ' must be ' + n + ' or less.'; },
    pattern: function (label) { return label + ' has an invalid format.'; },
    match: function (label, otherLabel) { return label + ' does not match ' + otherLabel + '.'; },
  };

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  /** Human-readable label for a field: explicit rule.label, else its <label for>, else the name humanized. */
  function fieldLabel(form, name, rule) {
    if (rule && rule.label) return rule.label;
    var labelEl = form.querySelector('label[for="' + cssEscape(fieldId(form, name)) + '"]');
    if (labelEl) return labelEl.textContent.replace(/\*\s*$/, '').trim();
    return name.replace(/_/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }

  function fieldEl(form, name) {
    return form.querySelector('[name="' + cssEscape(name) + '"]');
  }

  function fieldId(form, name) {
    var el = fieldEl(form, name);
    return el ? el.id : name;
  }

  function cssEscape(s) {
    return window.CSS && CSS.escape ? CSS.escape(s) : s.replace(/([^\w-])/g, '\\$1');
  }

  /** Find (or create) the .invalid-feedback element that sits right after this field. */
  function errorContainer(el) {
    var next = el.nextElementSibling;
    if (next && next.classList.contains('invalid-feedback')) {
      return next;
    }
    var div = document.createElement('div');
    div.className = 'invalid-feedback';
    if (el.id) div.id = el.id + '-error';
    el.insertAdjacentElement('afterend', div);
    return div;
  }

  function showFieldError(form, name, message) {
    var el = fieldEl(form, name);
    if (!el) return;
    el.classList.add('is-invalid');
    el.setAttribute('aria-invalid', 'true');
    var box = errorContainer(el);
    box.textContent = message;
    if (box.id) el.setAttribute('aria-describedby', box.id);
  }

  function clearFieldError(form, name) {
    var el = fieldEl(form, name);
    if (!el) return;
    el.classList.remove('is-invalid');
    el.removeAttribute('aria-invalid');
    var next = el.nextElementSibling;
    if (next && next.classList.contains('invalid-feedback')) {
      next.textContent = '';
    }
  }

  function clearAllErrors(form) {
    form.querySelectorAll('.is-invalid').forEach(function (el) {
      el.classList.remove('is-invalid');
      el.removeAttribute('aria-invalid');
    });
    form.querySelectorAll('.invalid-feedback').forEach(function (box) { box.textContent = ''; });
  }

  /**
   * Validate one field against its rule. Returns an error message string,
   * or null if valid. Does NOT touch the DOM — callers decide whether to
   * render it (so live-validation can choose to only *clear* errors, not
   * add new ones, while the user is still typing).
   */
  function checkField(form, name, rule) {
    var el = fieldEl(form, name);
    if (!el) return null;
    var value = (el.value ?? '').toString().trim();
    var label = fieldLabel(form, name, rule);

    var isEmpty = value === '';

    if (rule.required && isEmpty) {
      return (rule.messages && rule.messages.required) || DEFAULT_MESSAGES.required(label);
    }

    // Everything below only applies when there's a value — optional fields
    // stay valid when left blank.
    if (isEmpty) return null;

    if (rule.type === 'email' && !EMAIL_RE.test(value)) {
      return (rule.messages && rule.messages.email) || DEFAULT_MESSAGES.email();
    }

    if (rule.type === 'number') {
      if (value !== '' && isNaN(Number(value))) {
        return (rule.messages && rule.messages.number) || DEFAULT_MESSAGES.number();
      }
    }

    if (rule.minLength && value.length < rule.minLength) {
      return (rule.messages && rule.messages.minLength) || DEFAULT_MESSAGES.minLength(label, rule.minLength);
    }
    if (rule.maxLength && value.length > rule.maxLength) {
      return (rule.messages && rule.messages.maxLength) || DEFAULT_MESSAGES.maxLength(label, rule.maxLength);
    }

    if ((rule.min !== undefined || rule.max !== undefined) && !isNaN(Number(value))) {
      var num = Number(value);
      if (rule.min !== undefined && num < rule.min) {
        return (rule.messages && rule.messages.min) || DEFAULT_MESSAGES.min(label, rule.min);
      }
      if (rule.max !== undefined && num > rule.max) {
        return (rule.messages && rule.messages.max) || DEFAULT_MESSAGES.max(label, rule.max);
      }
    }

    if (rule.pattern && !(rule.pattern instanceof RegExp ? rule.pattern : new RegExp(rule.pattern)).test(value)) {
      return (rule.messages && rule.messages.pattern) || DEFAULT_MESSAGES.pattern(label);
    }

    if (rule.match) {
      var otherEl = fieldEl(form, rule.match);
      if (otherEl && value !== otherEl.value) {
        var otherLabel = fieldLabel(form, rule.match, null);
        return (rule.messages && rule.messages.match) || DEFAULT_MESSAGES.match(label, otherLabel);
      }
    }

    if (typeof rule.custom === 'function') {
      var result = rule.custom(value, new FormData(form), el);
      if (result === false) return (rule.messages && rule.messages.custom) || (label + ' is invalid.');
      if (typeof result === 'string') return result;
    }

    return null;
  }

  /** Validate + render one field. Returns true if valid. */
  function validateField(form, name, schema) {
    var rule = schema[name];
    if (!rule) return true;
    var error = checkField(form, name, rule);
    if (error) {
      showFieldError(form, name, error);
      return false;
    }
    clearFieldError(form, name);
    return true;
  }

  /** Validate the whole form against its schema. Renders every field's state. */
  function validateForm(form, schema) {
    var errors = {};
    var valid = true;
    Object.keys(schema).forEach(function (name) {
      if (!validateField(form, name, schema)) {
        valid = false;
        errors[name] = errorContainer(fieldEl(form, name)).textContent;
      }
    });
    return { valid: valid, errors: errors };
  }

  /** Scroll to + focus the first invalid field (handles fields inside a scrollable modal body). */
  function focusFirstInvalid(form) {
    var first = form.querySelector('.is-invalid');
    if (!first) return;
    if (typeof first.scrollIntoView === 'function') {
      first.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
    first.focus({ preventScroll: true });
  }

  /**
   * Map a backend { fieldName: 'message' } error object onto the form.
   * Returns the array of messages that didn't match any field on the form
   * (business-rule errors, etc.) so the caller can show those separately.
   */
  function mapBackendErrors(form, fieldErrors) {
    var unmapped = [];
    Object.keys(fieldErrors || {}).forEach(function (name) {
      if (fieldEl(form, name)) {
        showFieldError(form, name, fieldErrors[name]);
      } else {
        unmapped.push(fieldErrors[name]);
      }
    });
    focusFirstInvalid(form);
    return unmapped;
  }

  /**
   * Wire blur/change validation for every field in the schema, plus a
   * "clear as you fix it" listener: once a field is marked invalid, typing
   * that makes it valid again clears the error immediately. We never
   * *introduce* a new error while the user is still typing — only on
   * blur, change, or submit — per the "don't validate too aggressively"
   * requirement.
   */
  function attachLiveValidation(form, schema) {
    Object.keys(schema).forEach(function (name) {
      var el = fieldEl(form, name);
      if (!el) return;
      var eventName = (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'radio') ? 'change' : 'blur';

      el.addEventListener(eventName, function () { validateField(form, name, schema); });

      el.addEventListener('input', function () {
        if (el.classList.contains('is-invalid')) {
          validateField(form, name, schema);
        }
      });
    });
  }

  window.ShValidator = {
    validateForm: validateForm,
    validateField: validateField,
    showFieldError: showFieldError,
    clearFieldError: clearFieldError,
    clearAllErrors: clearAllErrors,
    mapBackendErrors: mapBackendErrors,
    focusFirstInvalid: focusFirstInvalid,
    attachLiveValidation: attachLiveValidation,
  };
})();
