<?php
/**
 * ajax/view.php — GET ?id=123 → full vessel record + gallery images.
 * Used to populate both the read-only View modal and to pre-fill the
 * Edit form.
 */
require_once __DIR__ . '/../../../includes/auth.php';
require_login();
require_once __DIR__ . '/../../../functions/helpers.php';
require_once __DIR__ . '/../../../functions/vessel_functions.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    json_error('Invalid vessel ID.', 400);
}

$vessel = get_vessel_with_images($id);
if (!$vessel) {
    json_error('Vessel not found.', 404);
}

$base = admin_base_url();
$vessel['images'] = array_map(function ($img) use ($base) {
    return [
        'id'  => (int) $img['id'],
        'url' => $base . '/uploads/vessels/' . rawurlencode($img['image']),
    ];
}, $vessel['images']);

json_response(['success' => true, 'data' => $vessel]);
