/**
 * modules/vessels/assets/vessels.js
 * ---------------------------------------------------------------------
 * Powers the Vessel list page: DataTables list, and Add / Edit / View /
 * Delete — all inside Bootstrap modals via fetch(), no page reloads.
 * ---------------------------------------------------------------------
 */
(function ($) {
  'use strict';

  var AJAX_BASE = window.location.pathname.replace(/\/index\.php$/, '') + '/ajax';
  var csrfToken = document.querySelector('#vesselForm input[name="csrf_token"]').value;

  var dataTable;
  var dropzone;
  var removedImageIds = [];

  // Field-level validation schema for the Add/Edit form (ShValidator —
  // assets/js/form-validator.js). Spec fields are optional, so only their
  // format/range is checked, not presence.
  var vesselSchema = {
    name: { required: true, maxLength: 150, label: 'Vessel Name' },
    length_m: { type: 'number', min: 0, label: 'Length' },
    breadth_m: { type: 'number', min: 0, label: 'Breadth' },
    depth_m: { type: 'number', min: 0, label: 'Depth' },
    gross_tonnage: { type: 'number', min: 0, label: 'Gross Tonnage' },
  };

  document.addEventListener('DOMContentLoaded', function () {
    initTable();
    initDropzone();
    bindFormEvents();

    var formEl = document.getElementById('vesselForm');
    ShValidator.attachLiveValidation(formEl, vesselSchema);

    // Unsaved-changes guard (assets/js/modal-guard.js) — the Add/Edit
    // modal also counts a newly dropped image or a removed existing image
    // as "dirty" even though those aren't plain form field values the
    // guard's own serializer can see.
    ShModalGuard.bind(document.getElementById('vesselFormModal'), formEl, {
      isDirtyExtra: function () { return dropzone.getFiles().length > 0 || removedImageIds.length > 0; },
    });
    // View is read-only (no form) and Delete only ever has an explicit
    // confirm/cancel — both still get the guard so an accidental outside
    // click or Escape can't dismiss them, per the CRUD modal standard.
    ShModalGuard.bind(document.getElementById('vesselViewModal'), null);
    ShModalGuard.bind(document.getElementById('vesselDeleteModal'), null);
  });

  function initTable() {
    dataTable = $('#vesselsTable').DataTable({
      ajax: {
        url: AJAX_BASE + '/list.php',
        dataSrc: 'data',
      },
      columns: [
        {
          data: 'thumbnail_url',
          orderable: false,
          render: function (url, type, row) {
            return url
              ? '<img src="' + escapeAttr(url) + '" class="sh-thumb" alt="">'
              : '<div class="sh-thumb d-flex align-items-center justify-content-center text-muted"><i class="bi bi-image"></i></div>';
          },
        },
        { data: 'name', render: escapeHtml },
        { data: 'length_m', render: fmtNum },
        { data: 'breadth_m', render: fmtNum },
        { data: 'depth_m', render: fmtNum },
        { data: 'gross_tonnage', render: fmtNum },
        {
          data: 'status',
          render: function (status) {
            var cls = status === 'published' ? 'sh-status-pill--published' : 'sh-status-pill--draft';
            return '<span class="sh-status-pill ' + cls + '">' + escapeHtml(status) + '</span>';
          },
        },
        {
          data: null,
          orderable: false,
          className: 'text-end',
          render: function (row) {
            return (
              '<div class="d-inline-flex gap-1">' +
              '<button type="button" class="sh-icon-btn btn-view" data-id="' + row.id + '" title="View"><i class="bi bi-eye"></i></button>' +
              '<button type="button" class="sh-icon-btn btn-edit" data-id="' + row.id + '" title="Edit"><i class="bi bi-pencil"></i></button>' +
              '<button type="button" class="sh-icon-btn sh-icon-btn--danger btn-delete" data-id="' + row.id + '" data-name="' + escapeAttr(row.name) + '" title="Delete"><i class="bi bi-trash"></i></button>' +
              '</div>'
            );
          },
        },
      ],
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50],
      pageLength: 10,
      responsive: true,
      language: { emptyTable: 'No vessels yet. Click "Add Vessel" to add your first ship.' },
    });

    $('#vesselsTable tbody').on('click', '.btn-view', function () { openViewModal($(this).data('id')); });
    $('#vesselsTable tbody').on('click', '.btn-edit', function () { openEditModal($(this).data('id')); });
    $('#vesselsTable tbody').on('click', '.btn-delete', function () { openDeleteModal($(this).data('id'), $(this).data('name')); });
  }

  function initDropzone() {
    dropzone = window.ShDropzone({
      dropzoneId: 'vesselDropzone',
      inputId: 'vesselImagesInput',
      previewId: 'newImagesPreview',
    });
  }

  function bindFormEvents() {
    document.getElementById('btnAddVessel').addEventListener('click', resetFormForAdd);

    document.getElementById('vesselFormModal').addEventListener('hidden.bs.modal', resetFormForAdd);

    document.getElementById('vesselForm').addEventListener('submit', function (e) {
      e.preventDefault();
      submitVesselForm();
    });

    document.getElementById('confirmDeleteBtn').addEventListener('click', confirmDelete);
  }

  function resetFormForAdd() {
    document.getElementById('vesselFormTitle').textContent = 'Add Vessel';
    document.getElementById('vesselForm').reset();
    document.getElementById('vesselId').value = '';
    document.getElementById('existingImages').innerHTML = '';
    document.getElementById('vesselFormAlert').classList.add('d-none');
    ShValidator.clearAllErrors(document.getElementById('vesselForm'));
    removedImageIds = [];
    dropzone.reset();
  }

  function openEditModal(id) {
    fetchJson(AJAX_BASE + '/view.php?id=' + encodeURIComponent(id))
      .then(function (res) {
        var v = res.data;
        document.getElementById('vesselFormTitle').textContent = 'Edit Vessel';
        document.getElementById('vesselId').value = v.id;
        document.getElementById('vesselName').value = v.name || '';
        document.getElementById('vesselLength').value = v.length_m ?? '';
        document.getElementById('vesselBreadth').value = v.breadth_m ?? '';
        document.getElementById('vesselDepth').value = v.depth_m ?? '';
        document.getElementById('vesselTonnage').value = v.gross_tonnage ?? '';
        document.getElementById('vesselDescription').value = v.description || '';
        document.getElementById('vesselStatus').value = v.status || 'published';

        removedImageIds = [];
        dropzone.reset();
        renderExistingImages(v.images || []);
        ShValidator.clearAllErrors(document.getElementById('vesselForm'));

        new bootstrap.Modal(document.getElementById('vesselFormModal')).show();
      })
      .catch(function (err) { alert(err.message || 'Could not load vessel.'); });
  }

  function renderExistingImages(images) {
    var container = document.getElementById('existingImages');
    container.innerHTML = '';
    images.forEach(function (img) {
      var item = document.createElement('div');
      item.className = 'sh-preview-item';
      item.dataset.imageId = img.id;

      var image = document.createElement('img');
      image.src = img.url;
      item.appendChild(image);

      var removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'sh-preview-remove';
      removeBtn.innerHTML = '<i class="bi bi-x"></i>';
      removeBtn.addEventListener('click', function () {
        removedImageIds.push(img.id);
        item.remove();
      });
      item.appendChild(removeBtn);

      container.appendChild(item);
    });
  }

  function openViewModal(id) {
    var body = document.getElementById('vesselViewBody');
    body.innerHTML = '<div class="text-center text-muted py-4">Loading…</div>';
    new bootstrap.Modal(document.getElementById('vesselViewModal')).show();

    fetchJson(AJAX_BASE + '/view.php?id=' + encodeURIComponent(id))
      .then(function (res) {
        var v = res.data;
        var gallery = (v.images || [])
          .map(function (img) {
            return '<div class="col-4"><img src="' + escapeAttr(img.url) + '" class="rounded" style="width:100%;height:120px;object-fit:cover;"></div>';
          })
          .join('');

        body.innerHTML =
          '<h4 class="mb-3">' + escapeHtml(v.name) + '</h4>' +
          (gallery ? '<div class="row g-2 mb-3">' + gallery + '</div>' : '') +
          '<table class="table table-sm">' +
          specRow('Length', v.length_m, 'm') +
          specRow('Breadth', v.breadth_m, 'm') +
          specRow('Depth', v.depth_m, 'm') +
          specRow('Gross Tonnage', v.gross_tonnage, '') +
          '</table>' +
          (v.description ? '<p class="text-muted mb-0">' + escapeHtml(v.description) + '</p>' : '');
      })
      .catch(function (err) {
        body.innerHTML = '<div class="alert alert-danger mb-0">' + escapeHtml(err.message || 'Could not load vessel.') + '</div>';
      });
  }

  function specRow(label, value, unit) {
    if (value === null || value === undefined || value === '') return '';
    return '<tr><th class="text-muted">' + label + '</th><td class="text-end fw-semibold">' + Number(value).toFixed(2) + (unit ? ' ' + unit : '') + '</td></tr>';
  }

  function openDeleteModal(id, name) {
    document.getElementById('deleteVesselName').textContent = name;
    document.getElementById('confirmDeleteBtn').dataset.id = id;
    new bootstrap.Modal(document.getElementById('vesselDeleteModal')).show();
  }

  function confirmDelete() {
    var btn = document.getElementById('confirmDeleteBtn');
    var id = btn.dataset.id;
    toggleSpinner(btn, 'deleteSpinner', true);

    fetch(AJAX_BASE + '/delete.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ id: id, csrf_token: csrfToken }),
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (res) {
        if (!res.ok || !res.data.success) throw new Error(res.data.message || 'Delete failed.');
        bootstrap.Modal.getInstance(document.getElementById('vesselDeleteModal')).hide();
        dataTable.ajax.reload(null, false);
      })
      .catch(function (err) { alert(err.message); })
      .finally(function () { toggleSpinner(btn, 'deleteSpinner', false); });
  }

  function submitVesselForm() {
    var form = document.getElementById('vesselForm');
    var id = document.getElementById('vesselId').value;
    var isEdit = !!id;
    var url = AJAX_BASE + (isEdit ? '/update.php' : '/create.php');

    var validation = ShValidator.validateForm(form, vesselSchema);
    if (!validation.valid) {
      ShValidator.focusFirstInvalid(form);
      return;
    }

    var formData = new FormData(form);
    dropzone.getFiles().forEach(function (file) { formData.append('images[]', file); });
    if (isEdit) {
      formData.append('remove_image_ids', JSON.stringify(removedImageIds));
    }

    var submitBtn = document.getElementById('vesselFormSubmit');
    var alertBox = document.getElementById('vesselFormAlert');
    alertBox.classList.add('d-none');
    toggleSpinner(submitBtn, 'vesselFormSpinner', true);

    fetch(url, {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: formData,
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (res) {
        if (res.ok && res.data.success) {
          bootstrap.Modal.getInstance(document.getElementById('vesselFormModal')).hide();
          dataTable.ajax.reload(null, false);
          return;
        }
        if (res.data.errors) {
          // Field-level errors from json_field_errors() — show each under
          // its input; anything that doesn't map to a field (business
          // rules, etc.) falls back to the top alert box.
          var unmapped = ShValidator.mapBackendErrors(form, res.data.errors);
          if (unmapped.length) {
            alertBox.textContent = unmapped.join(' ');
            alertBox.classList.remove('d-none');
          }
          return;
        }
        throw new Error(res.data.message || 'Save failed.');
      })
      .catch(function (err) {
        alertBox.textContent = err.message;
        alertBox.classList.remove('d-none');
      })
      .finally(function () { toggleSpinner(submitBtn, 'vesselFormSpinner', false); });
  }

  function toggleSpinner(btn, spinnerId, loading) {
    btn.disabled = loading;
    document.getElementById(spinnerId).classList.toggle('d-none', !loading);
  }

  function fetchJson(url) {
    return fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } }).then(function (r) {
      return r.json().then(function (data) {
        if (!r.ok || !data.success) throw new Error(data.message || 'Request failed.');
        return data;
      });
    });
  }

  function fmtNum(value) {
    return value === null || value === undefined || value === '' ? '<span class="text-muted">—</span>' : Number(value).toFixed(2);
  }

  function escapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function escapeAttr(str) {
    return escapeHtml(str);
  }
})(jQuery);
