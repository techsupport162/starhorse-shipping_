<?php
/**
 * modules/vessels/index.php
 * -----------------------------------------------------------------------
 * Vessel list screen. The table itself is populated client-side by
 * DataTables from ajax/list.php. Add / Edit / View / Delete all happen
 * inside Bootstrap modals via AJAX — this page never redirects.
 * -----------------------------------------------------------------------
 */
require_once __DIR__ . '/../../includes/auth.php';
require_login();
require_once __DIR__ . '/../../functions/helpers.php';

$pageTitle = 'Vessels';
$activeNav = 'vessels';
$extraScripts = [admin_base_url() . '/modules/vessels/assets/vessels.js'];

require __DIR__ . '/../../includes/header.php';
?>

<div class="sh-card">
  <div class="sh-card__header">
    <h2 class="sh-card__title">Fleet</h2>
    <button type="button" class="btn btn-sh-primary" data-bs-toggle="modal" data-bs-target="#vesselFormModal" id="btnAddVessel">
      <i class="bi bi-plus-lg me-1"></i> Add Vessel
    </button>
  </div>
  <div class="sh-card__body">
    <table id="vesselsTable" class="table sh-table align-middle w-100">
      <thead>
        <tr>
          <th>Image</th>
          <th>Vessel Name</th>
          <th>Length</th>
          <th>Breadth</th>
          <th>Depth</th>
          <th>Gross Tonnage</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody><!-- populated by DataTables via ajax/list.php --></tbody>
    </table>
  </div>
</div>

<!-- =====================================================================
     Add / Edit Vessel Modal
     Same modal is reused for both — JS toggles title/mode and pre-fills
     fields when editing. Submits via fetch() as multipart/form-data
     (needed for file uploads) to ajax/create.php or ajax/update.php.
     ===================================================================== -->
<div class="modal fade" id="vesselFormModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <form id="vesselForm" novalidate>
        <div class="modal-header">
          <h5 class="modal-title" id="vesselFormTitle">Add Vessel</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="vesselFormAlert" class="alert alert-danger d-none"></div>

          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="id" id="vesselId" value="">

          <div class="mb-3">
            <label class="form-label small fw-semibold">Vessel Name *</label>
            <input type="text" class="form-control" name="name" id="vesselName" placeholder="e.g. M/V VIRGEN DE PEÑAFRANCIA I" required>
          </div>

          <div class="row g-3">
            <div class="col-6 col-md-3">
              <label class="form-label small fw-semibold">Length (m)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="length_m" id="vesselLength">
            </div>
            <div class="col-6 col-md-3">
              <label class="form-label small fw-semibold">Breadth (m)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="breadth_m" id="vesselBreadth">
            </div>
            <div class="col-6 col-md-3">
              <label class="form-label small fw-semibold">Depth (m)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="depth_m" id="vesselDepth">
            </div>
            <div class="col-6 col-md-3">
              <label class="form-label small fw-semibold">Gross Tonnage</label>
              <input type="number" step="0.01" min="0" class="form-control" name="gross_tonnage" id="vesselTonnage">
            </div>
          </div>

          <div class="mt-3">
            <label class="form-label small fw-semibold">Description</label>
            <textarea class="form-control" name="description" id="vesselDescription" rows="3" placeholder="Optional short description shown on the public site"></textarea>
          </div>

          <div class="mt-3">
            <label class="form-label small fw-semibold">Status</label>
            <select class="form-select" name="status" id="vesselStatus">
              <option value="published">Published (visible on site)</option>
              <option value="draft">Draft (hidden)</option>
            </select>
          </div>

          <hr class="my-3">

          <div class="mb-2 d-flex align-items-center justify-content-between">
            <label class="form-label small fw-semibold mb-0">Images / Gallery</label>
            <span class="text-muted small">JPG, PNG, WEBP, or GIF — up to 5MB each</span>
          </div>

          <div id="existingImages" class="sh-preview-grid mb-2"><!-- existing images injected here when editing --></div>

          <div class="sh-dropzone" id="vesselDropzone">
            <i class="bi bi-cloud-arrow-up d-block mb-2"></i>
            <div class="small fw-semibold">Drag &amp; drop images here, or click to browse</div>
            <div class="text-muted small">Multiple images supported</div>
          </div>
          <input type="file" id="vesselImagesInput" accept="image/*" multiple hidden>
          <div class="sh-preview-grid" id="newImagesPreview"><!-- new file previews --></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sh-outline" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-sh-primary" id="vesselFormSubmit">
            <span class="submit-label">Save Vessel</span>
            <span class="spinner-border spinner-border-sm ms-1 d-none" id="vesselFormSpinner"></span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- =====================================================================
     View Vessel Modal (read-only)
     ===================================================================== -->
<div class="modal fade" id="vesselViewModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Vessel Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="vesselViewBody">
        <div class="text-center text-muted py-4">Loading…</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sh-outline" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- =====================================================================
     Delete Confirmation Modal
     ===================================================================== -->
<div class="modal fade" id="vesselDeleteModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Delete Vessel</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p class="mb-0">Are you sure you want to delete <strong id="deleteVesselName"></strong>? This will also remove all of its gallery images. This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sh-outline" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDeleteBtn">
          <span class="submit-label">Delete</span>
          <span class="spinner-border spinner-border-sm ms-1 d-none" id="deleteSpinner"></span>
        </button>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
