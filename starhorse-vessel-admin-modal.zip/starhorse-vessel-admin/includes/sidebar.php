<?php
/**
 * includes/sidebar.php
 * -----------------------------------------------------------------------
 * Included by header.php. Uses $activeNav (set by the calling page) to
 * highlight the current section. Only "vessels" is fully wired up today;
 * the rest are placeholder modules ready for future expansion.
 * -----------------------------------------------------------------------
 */
$navItems = [
    ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'bi-speedometer2',        'href' => $base . '/dashboard.php',                'soon' => false],
    ['key' => 'vessels',   'label' => 'Vessels',   'icon' => 'bi-water',               'href' => $base . '/modules/vessels/index.php',    'soon' => false],
    ['key' => 'news',      'label' => 'News',      'icon' => 'bi-newspaper',           'href' => $base . '/modules/news/index.php',       'soon' => true],
    ['key' => 'schedules', 'label' => 'Schedules', 'icon' => 'bi-calendar3',           'href' => $base . '/modules/schedules/index.php',  'soon' => true],
    ['key' => 'settings',  'label' => 'Settings',  'icon' => 'bi-gear',                'href' => $base . '/modules/settings/index.php',   'soon' => true],
];
?>
<aside class="sh-sidebar">
  <div class="sh-sidebar__brand">
    <a href="<?= htmlspecialchars($base . '/dashboard.php', ENT_QUOTES, 'UTF-8') ?>" class="sh-logo-link">
      <img src="<?= htmlspecialchars($base . '/assets/images/logo-placeholder.png', ENT_QUOTES, 'UTF-8') ?>"
           alt="Starhorse Shipping Line, Inc."
           class="sh-logo-full">
      <img src="<?= htmlspecialchars($base . '/assets/images/logo-placeholder.png', ENT_QUOTES, 'UTF-8') ?>"
           alt="Starhorse"
           class="sh-logo-compact">
    </a>
  </div>

  <nav class="sh-sidebar__nav">
    <div class="sh-nav-section-title">Content</div>
    <a class="sh-nav-item <?= $activeNav === 'dashboard' ? 'active' : '' ?>" href="<?= htmlspecialchars($navItems[0]['href'], ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-speedometer2"></i>
      <span class="sh-nav-label">Dashboard</span>
    </a>
    <a class="sh-nav-item <?= $activeNav === 'vessels' ? 'active' : '' ?>" href="<?= htmlspecialchars($navItems[1]['href'], ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-water"></i>
      <span class="sh-nav-label">Vessels</span>
    </a>

    <?php /* User Management is only ever rendered for administrators — this
             hides it in the UI, but the real security boundary is
             require_admin() on every page/endpoint inside modules/users/. */ ?>
    <?php if (is_admin()): ?>
    <a class="sh-nav-item <?= $activeNav === 'users' ? 'active' : '' ?>" href="<?= htmlspecialchars($base . '/modules/users/index.php', ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-people"></i>
      <span class="sh-nav-label">User Management</span>
    </a>
    <?php endif; ?>

    <?php /* News/Schedules/Settings are administration modules — same
             admin-only rule as User Management, enforced server-side by
             require_admin() on each page; hidden here as a UX nicety. */ ?>
    <?php if (is_admin()): ?>
    <a class="sh-nav-item <?= $activeNav === 'news' ? 'active' : '' ?>" href="<?= htmlspecialchars($navItems[2]['href'], ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-newspaper"></i>
      <span class="sh-nav-label">News</span>
      <span class="sh-badge-soon">Soon</span>
    </a>
    <a class="sh-nav-item <?= $activeNav === 'schedules' ? 'active' : '' ?>" href="<?= htmlspecialchars($navItems[3]['href'], ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-calendar3"></i>
      <span class="sh-nav-label">Schedules</span>
      <span class="sh-badge-soon">Soon</span>
    </a>
    <a class="sh-nav-item <?= $activeNav === 'settings' ? 'active' : '' ?>" href="<?= htmlspecialchars($navItems[4]['href'], ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-gear"></i>
      <span class="sh-nav-label">Settings</span>
      <span class="sh-badge-soon">Soon</span>
    </a>
    <?php endif; ?>
  </nav>

  <div class="sh-sidebar__footer">
    &copy; <?= date('Y') ?> Starhorse Shipping Line, Inc.
  </div>
</aside>
