<?php
/**
 * dashboard.php — CMS landing page. Not vessel-specific: shows overall
 * site stats and quick links so it reads as a real CMS home, not a
 * single-module tool.
 */
require_once __DIR__ . '/includes/auth.php';
require_login();
require_once __DIR__ . '/functions/helpers.php';
require_once __DIR__ . '/functions/vessel_functions.php';
require_once __DIR__ . '/functions/user_functions.php';

$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
$vesselCount = count_all_vessels();
$userCount = count_all_users();

require __DIR__ . '/includes/header.php';
?>

<div class="row g-3 mb-4">
  <div class="col-sm-6 col-xl-3">
    <div class="sh-card sh-stat-card">
      <span class="sh-stat-icon" style="background: var(--sh-primary);"><i class="bi bi-water"></i></span>
      <div>
        <div class="sh-stat-value"><?= (int) $vesselCount ?></div>
        <div class="sh-stat-label">Vessels in Fleet</div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-xl-3">
    <div class="sh-card sh-stat-card">
      <span class="sh-stat-icon" style="background: var(--sh-navy);"><i class="bi bi-newspaper"></i></span>
      <div>
        <div class="sh-stat-value">0</div>
        <div class="sh-stat-label">News Articles</div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-xl-3">
    <div class="sh-card sh-stat-card">
      <span class="sh-stat-icon" style="background: var(--sh-teal);"><i class="bi bi-calendar3"></i></span>
      <div>
        <div class="sh-stat-value">0</div>
        <div class="sh-stat-label">Schedules</div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-xl-3">
    <div class="sh-card sh-stat-card">
      <span class="sh-stat-icon" style="background: var(--sh-gold);"><i class="bi bi-people"></i></span>
      <div>
        <div class="sh-stat-value"><?= (int) $userCount ?></div>
        <div class="sh-stat-label">System Users</div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="sh-card h-100">
      <div class="sh-card__header">
        <h2 class="sh-card__title">Welcome back, <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin', ENT_QUOTES, 'UTF-8') ?></h2>
      </div>
      <div class="sh-card__body">
        <p class="text-muted mb-3">This is your CMS home base. Vessels and User Management are fully functional today — manage your fleet and staff accounts right from here. Other sections below are staged for future rollout.</p>
        <a href="modules/vessels/index.php" class="btn btn-sh-primary">
          <i class="bi bi-water me-1"></i> Manage Vessels
        </a>
        <?php if (is_admin()): ?>
        <a href="modules/users/index.php" class="btn btn-sh-outline ms-2">
          <i class="bi bi-people me-1"></i> Manage Users
        </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="sh-card h-100">
      <div class="sh-card__header">
        <h2 class="sh-card__title">Coming Up</h2>
      </div>
      <div class="sh-card__body">
        <ul class="list-unstyled mb-0 small">
          <li class="mb-2"><i class="bi bi-newspaper me-2 text-muted"></i>News &amp; Announcements module</li>
          <li class="mb-2"><i class="bi bi-calendar3 me-2 text-muted"></i>Route Schedules module</li>
          <li class="mb-0"><i class="bi bi-gear me-2 text-muted"></i>Site Settings</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
