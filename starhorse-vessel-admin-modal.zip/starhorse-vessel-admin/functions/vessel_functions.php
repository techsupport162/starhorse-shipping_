<?php
/**
 * functions/vessel_functions.php
 * -----------------------------------------------------------------------
 * All database access for the Vessel module lives here. Both the public
 * site (sections/vessels.php, read-only) and the admin panel (full CRUD)
 * include this file. Every query uses prepared statements.
 * -----------------------------------------------------------------------
 */

require_once __DIR__ . '/../../config/database.php';

/**
 * PUBLIC SITE: all published vessels, each with its ordered gallery images.
 * Returns each vessel with an 'images' array (filenames only) and a
 * convenience 'image' key set to the first image (used for card thumbnails).
 */
function get_published_vessels(): array
{
    $pdo = get_db();

    $vessels = $pdo->query(
        "SELECT id, name, length_m, breadth_m, depth_m, gross_tonnage, description
         FROM vessels
         WHERE status = 'published'
         ORDER BY sort_order ASC, created_at DESC"
    )->fetchAll();

    if (!$vessels) {
        return [];
    }

    $ids = array_column($vessels, 'id');
    $images = fetch_images_for_vessels($ids);

    foreach ($vessels as &$vessel) {
        $vessel['images'] = $images[$vessel['id']] ?? [];
        $vessel['image']  = $vessel['images'][0] ?? null;
    }
    unset($vessel);

    return $vessels;
}

/** Fetch ordered image filenames grouped by vessel_id, for a set of vessel IDs. */
function fetch_images_for_vessels(array $vesselIds): array
{
    if (empty($vesselIds)) {
        return [];
    }

    $pdo = get_db();
    $placeholders = implode(',', array_fill(0, count($vesselIds), '?'));

    $stmt = $pdo->prepare(
        "SELECT vessel_id, image FROM vessel_images
         WHERE vessel_id IN ($placeholders)
         ORDER BY sort_order ASC, id ASC"
    );
    $stmt->execute($vesselIds);

    $grouped = [];
    foreach ($stmt->fetchAll() as $row) {
        $grouped[$row['vessel_id']][] = $row['image'];
    }
    return $grouped;
}

/**
 * ADMIN: paginated, searchable, sortable vessel list.
 *
 * @return array{rows: array, total: int}
 */
function get_vessels_for_admin(string $search = '', int $limit = 10, int $offset = 0, string $orderBy = 'created_at', string $orderDir = 'DESC'): array
{
    $pdo = get_db();

    $allowedOrderBy = ['name', 'length_m', 'breadth_m', 'depth_m', 'gross_tonnage', 'created_at'];
    if (!in_array($orderBy, $allowedOrderBy, true)) {
        $orderBy = 'created_at';
    }
    $orderDir = strtoupper($orderDir) === 'ASC' ? 'ASC' : 'DESC';

    $where  = '';
    $params = [];
    if ($search !== '') {
        $where = 'WHERE v.name LIKE :search';
        $params[':search'] = '%' . $search . '%';
    }

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM vessels v $where");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $sql = "SELECT v.id, v.name, v.length_m, v.breadth_m, v.depth_m, v.gross_tonnage,
                   v.status, v.created_at, v.updated_at,
                   (SELECT image FROM vessel_images vi
                    WHERE vi.vessel_id = v.id
                    ORDER BY vi.sort_order ASC, vi.id ASC LIMIT 1) AS thumbnail
            FROM vessels v
            $where
            ORDER BY v.$orderBy $orderDir
            LIMIT :limit OFFSET :offset";

    $stmt = $pdo->prepare($sql);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    return ['rows' => $stmt->fetchAll(), 'total' => $total];
}

/** Single vessel with its full ordered image gallery (id + filename), for View/Edit. */
function get_vessel_with_images(int $id): ?array
{
    $pdo = get_db();

    $stmt = $pdo->prepare('SELECT * FROM vessels WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $vessel = $stmt->fetch();

    if (!$vessel) {
        return null;
    }

    $imgStmt = $pdo->prepare(
        'SELECT id, image FROM vessel_images WHERE vessel_id = :id ORDER BY sort_order ASC, id ASC'
    );
    $imgStmt->execute([':id' => $id]);
    $vessel['images'] = $imgStmt->fetchAll();

    return $vessel;
}

/** Insert a new vessel. Returns the new vessel's ID. */
function create_vessel(array $data): int
{
    $pdo = get_db();

    $stmt = $pdo->prepare(
        'INSERT INTO vessels (name, length_m, breadth_m, depth_m, gross_tonnage, description, status)
         VALUES (:name, :length_m, :breadth_m, :depth_m, :gross_tonnage, :description, :status)'
    );
    $stmt->execute([
        ':name'          => $data['name'],
        ':length_m'      => $data['length_m'],
        ':breadth_m'     => $data['breadth_m'],
        ':depth_m'       => $data['depth_m'],
        ':gross_tonnage' => $data['gross_tonnage'],
        ':description'   => $data['description'],
        ':status'        => $data['status'] ?? 'published',
    ]);

    return (int) $pdo->lastInsertId();
}

/** Update an existing vessel's core fields. */
function update_vessel(int $id, array $data): bool
{
    $pdo = get_db();

    $stmt = $pdo->prepare(
        'UPDATE vessels SET
            name = :name,
            length_m = :length_m,
            breadth_m = :breadth_m,
            depth_m = :depth_m,
            gross_tonnage = :gross_tonnage,
            description = :description,
            status = :status
         WHERE id = :id'
    );

    return $stmt->execute([
        ':name'          => $data['name'],
        ':length_m'      => $data['length_m'],
        ':breadth_m'     => $data['breadth_m'],
        ':depth_m'       => $data['depth_m'],
        ':gross_tonnage' => $data['gross_tonnage'],
        ':description'   => $data['description'],
        ':status'        => $data['status'] ?? 'published',
        ':id'            => $id,
    ]);
}

/** Delete a vessel (its vessel_images rows cascade via FK) and remove image files from disk. */
function delete_vessel(int $id): bool
{
    $pdo = get_db();

    $filenames = array_column(get_vessel_image_rows($id), 'image');

    $stmt = $pdo->prepare('DELETE FROM vessels WHERE id = :id');
    $result = $stmt->execute([':id' => $id]);

    if ($result) {
        foreach ($filenames as $filename) {
            delete_image_file($filename);
        }
    }

    return $result;
}

/** Raw image rows (id, image) for a vessel, ordered. */
function get_vessel_image_rows(int $vesselId): array
{
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT id, image FROM vessel_images WHERE vessel_id = :id ORDER BY sort_order ASC, id ASC');
    $stmt->execute([':id' => $vesselId]);
    return $stmt->fetchAll();
}

/** Attach an already-uploaded image filename to a vessel. */
function add_vessel_image(int $vesselId, string $filename, int $sortOrder = 0): int
{
    $pdo = get_db();
    $stmt = $pdo->prepare(
        'INSERT INTO vessel_images (vessel_id, image, sort_order) VALUES (:vessel_id, :image, :sort_order)'
    );
    $stmt->execute([':vessel_id' => $vesselId, ':image' => $filename, ':sort_order' => $sortOrder]);
    return (int) $pdo->lastInsertId();
}

/** Delete a single gallery image (DB row + file on disk). Returns false if not found. */
function delete_vessel_image(int $imageId): bool
{
    $pdo = get_db();

    $stmt = $pdo->prepare('SELECT image FROM vessel_images WHERE id = :id');
    $stmt->execute([':id' => $imageId]);
    $filename = $stmt->fetchColumn();

    if ($filename === false) {
        return false;
    }

    $del = $pdo->prepare('DELETE FROM vessel_images WHERE id = :id');
    $del->execute([':id' => $imageId]);

    delete_image_file($filename);

    return true;
}

/** Remove an image file from uploads/vessels/ if it exists. */
function delete_image_file(string $filename): void
{
    $path = __DIR__ . '/../uploads/vessels/' . basename($filename);
    if (is_file($path)) {
        @unlink($path);
    }
}

/** Simple dashboard stat: total vessel count. */
function count_all_vessels(): int
{
    return (int) get_db()->query('SELECT COUNT(*) FROM vessels')->fetchColumn();
}
